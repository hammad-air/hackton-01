Please put all the images inside the images folder.
